<?php ob_start(); ?>
<?php require('header.php') ?>

		<section id="whiteSpace" style="height:1000px;overflow:auto;">
			<?php
				session_start();
				if(isset($_SESSION['username'])){
					
					date_default_timezone_set('Asia/Calcutta');
					$date = date('Y-m-d H:i:s', time());
					echo '<div style="background-color:#f1f1f1;margin:10px 0px;padding:5px;">Hi '.$_SESSION['username'].'.<div class="shortlink" style="float:right;"><a href="logout.php">Logout</a></div></div>';
					$currentuserusername=$_SESSION['username'];
					require('connection.php');
					$queryretrievecurrentuserdetails="select * from usernamepassword where username='$currentuserusername'";
					$resultretrievecurrentuserdetails=mysql_query($queryretrievecurrentuserdetails);
					if($resultretrievecurrentuserdetails){
						if(mysql_num_rows($resultretrievecurrentuserdetails)==1){
							$arraycurrentuser=mysql_fetch_assoc($resultretrievecurrentuserdetails);
							$currentuserfirstname=$arraycurrentuser['firstname'];
							$currentuserlastname=$arraycurrentuser['lastname'];
							$currentuseremail=$arraycurrentuser['email'];
							$currentuserid=$arraycurrentuser['id'];
						}
					}
					
					// remove profile pic
						if(isset($_POST['removeprofilepicbutton'])){
							require('connection.php');
							$queryremoveprofilepic="delete from ".$_SESSION['username']."photos where name='profilepic'";
							$resultremoveprofilepic=mysql_query($queryremoveprofilepic);
							$queryremoveprofilepicsmall="delete from ".$_SESSION['username']."photos where name='profilepicsmall'";
							$resultremoveprofilepicsmall=mysql_query($queryremoveprofilepicsmall);
						}
						
						
					$queryretrieveprofilepic="select * from ".$_SESSION['username']."photos where name='profilepic'";
					$resultretrieveprofilepic=mysql_query($queryretrieveprofilepic);
					if($resultretrieveprofilepic){
						if(mysql_num_rows($resultretrieveprofilepic)==1){
							$arrayretrieveprofilepic=mysql_fetch_assoc($resultretrieveprofilepic);
							$imagepath=$arrayretrieveprofilepic['path'];
						}else{
							$imagepath='';
						}
					}
					?>
					<table cellpadding="5px" cellspacing="5px" border="0" id="accountlinks">
						<tr><td>
							<?php
							
									
									
								// photo upload
									if(isset($_POST['submit'])){
										if($_FILES['imagefile']['error']>0){
											echo '<div class="notice">Please select some image file first.</div>';
										}else if($_FILES['imagefile']['size']>2097152){
											echo '<div class="notice">File size is greater than 2 MB.Choose<br/>image below specified size limit.</div>';
										}else{
											$imagename=$_FILES['imagefile']['name'];
											$filename = $_FILES['imagefile']['name'];
											$filesize = $_FILES['imagefile']['size'];
											$filetype = $_FILES['imagefile']['type'];
											$filetemplocation = $_FILES['imagefile']['tmp_name'];
											$fileextension=@end(@explode('.',$filename));
											$max_width_small=40;
											$max_height_small=40;
											$max_width_big=200;
											$max_height_big=200;
											move_uploaded_file($filetemplocation,'upload/'.$currentuserusername.$filename);
											$filename='upload/'.$currentuserusername.$filename;

											if($fileextension=='jpg'){
												list($width,$height)=getimagesize($filename);
												$ratio_small=min($max_width_small/$width,$max_height_small/$height);
												$ratio_big=min($max_width_big/$width,$max_height_big/$height);
												$new_width_small=ceil($ratio_small*$width);
												$new_height_small=ceil($ratio_small*$height);
												$new_width_big=ceil($ratio_big*$width);
												$new_height_big=ceil($ratio_big*$height);
												$oldimage=imagecreatefromjpeg($filename);
												$newimage_small=imagecreatetruecolor($new_width_small,$new_height_small);
												$newimage_big=imagecreatetruecolor($new_width_big,$new_height_big);
												imagecopyresampled($newimage_small, $oldimage, 0, 0, 0, 0, $new_width_small, $new_height_small, $width, $height);
												imagecopyresampled($newimage_big, $oldimage, 0, 0, 0, 0, $new_width_big, $new_height_big, $width, $height);
												$newlocation_small='uploadsmall/small '.$currentuserusername.$imagename;
												$newlocation_big='uploadbig/big '.$currentuserusername.$imagename;
												header('Content-type:image/jpeg');
												imagejpeg($newimage_small, $newlocation_small, 100);
												//imagejpeg($newimage_small, null, 100);
												imagejpeg($newimage_big, $newlocation_big, 100);
												//imagejpeg($newimage_big, null, 100);
												
												require('connection.php');
												$newlocation_small=mysql_real_escape_string($newlocation_small);
												$newlocation_big=mysql_real_escape_string($newlocation_big);
												$queryinsertpath="insert into ".$_SESSION['username']."photos (name,path)values('profilepic','$newlocation_big')";
												$resultinsertpath=mysql_query($queryinsertpath);
												$queryinsertpathsmall="insert into ".$_SESSION['username']."photos (name,path)values('profilepicsmall','$newlocation_small')";
												$resultinsertpathsmall=mysql_query($queryinsertpathsmall);
												
												
												imagedestroy($oldimage);
												imagedestroy($newimage_small);
												imagedestroy($newimage_big);
												header("Refresh: 0; url=account.php");
											}else if($fileextension=='png'){
												list($width,$height)=getimagesize($filename);
												$ratio_small=min($max_width_small/$width,$max_height_small/$height);
												$ratio_big=min($max_width_big/$width,$max_height_big/$height);
												$new_width_small=ceil($ratio_small*$width);
												$new_height_small=ceil($ratio_small*$height);
												$new_width_big=ceil($ratio_big*$width);
												$new_height_big=ceil($ratio_big*$height);
												$oldimage=imagecreatefrompng($filename);
												$newimage_small=imagecreatetruecolor($new_width_small,$new_height_small);
												$newimage_big=imagecreatetruecolor($new_width_big,$new_height_big);
												imagecopyresampled($newimage_small, $oldimage, 0, 0, 0, 0, $new_width_small, $new_height_small, $width, $height);
												imagecopyresampled($newimage_big, $oldimage, 0, 0, 0, 0, $new_width_big, $new_height_big, $width, $height);
												$newlocation_small='uploadsmall/small '.$currentuserusername.$imagename;
												$newlocation_big='uploadbig/big '.$currentuserusername.$imagename;
												header('Content-type:image/png');
												imagepng($newimage_small, $newlocation_small);
												//imagepng($newimage_small, null, 9, PNG_NO_FILTER);
												imagepng($newimage_big, $newlocation_big);
												//imagepng($newimage_big, null, 9, PNG_NO_FILTER);
												
												
												require('connection.php');
												$newlocation_small=mysql_real_escape_string($newlocation_small);
												$newlocation_big=mysql_real_escape_string($newlocation_big);
												$queryinsertpath="insert into ".$_SESSION['username']."photos (name,path)values('profilepic','$newlocation_big')";
												$resultinsertpath=mysql_query($queryinsertpath);
												$queryinsertpathsmall="insert into ".$_SESSION['username']."photos (name,path)values('profilepicsmall','$newlocation_small')";
												$resultinsertpathsmall=mysql_query($queryinsertpathsmall);
												
												imagedestroy($oldimage);
												imagedestroy($newimage_small);
												imagedestroy($newimage_big);
												header("Refresh: 0; url=account.php");
											}else if($fileextension=='gif'){
												list($width,$height)=getimagesize($filename);
												$ratio_small=min($max_width_small/$width,$max_height_small/$height);
												$ratio_big=min($max_width_big/$width,$max_height_big/$height);
												$new_width_small=ceil($ratio_small*$width);
												$new_height_small=ceil($ratio_small*$height);
												$new_width_big=ceil($ratio_big*$width);
												$new_height_big=ceil($ratio_big*$height);
												$oldimage=imagecreatefromgif($filename);
												$newimage_small=imagecreatetruecolor($new_width_small,$new_height_small);
												$newimage_big=imagecreatetruecolor($new_width_big,$new_height_big);
												imagecopyresampled($newimage_small, $oldimage, 0, 0, 0, 0, $new_width_small, $new_height_small, $width, $height);
												imagecopyresampled($newimage_big, $oldimage, 0, 0, 0, 0, $new_width_big, $new_height_big, $width, $height);
												$newlocation_small='uploadsmall/small '.$currentuserusername.$imagename;
												$newlocation_big='uploadbig/big '.$currentuserusername.$imagename;
												header('Content-type:image/gif');
												imagegif($newimage_small, $newlocation_small);
												//imagegif($newimage_small, null);
												imagegif($newimage_big, $newlocation_big);
												//imagegif($newimage_big, null);
												
												require('connection.php');
												$newlocation_small=mysql_real_escape_string($newlocation_small);
												$newlocation_big=mysql_real_escape_string($newlocation_big);
												$queryinsertpath="insert into ".$_SESSION['username']."photos (name,path)values('profilepic','$newlocation_big')";
												$resultinsertpath=mysql_query($queryinsertpath);
												$queryinsertpathsmall="insert into ".$_SESSION['username']."photos (name,path)values('profilepicsmall','$newlocation_small')";
												$resultinsertpathsmall=mysql_query($queryinsertpathsmall);
												
												imagedestroy($oldimage);
												imagedestroy($newimage_small);
												imagedestroy($newimage_big);
												header("Refresh: 0; url=account.php");
											}else{
												echo '<div class="notice">Image is not in jpg,png or gif format.</div>';
											}
										}

									}
									// upload changed profile pic
									if(isset($_POST['changeprofilepicbutton'])){
										if($_FILES['changedimagefile']['error']>0){
											echo '<div class="notice">Please select some image file first.</div>';
										}else if($_FILES['changedimagefile']['size']>2097152){
											echo '<div class="notice">File size is greater than 2 MB.Choose<br/>image below specified size limit.</div>';
										}else{
											$imagename=$_FILES['changedimagefile']['name'];
											$filename = $_FILES['changedimagefile']['name'];
											$filesize = $_FILES['changedimagefile']['size'];
											$filetype = $_FILES['changedimagefile']['type'];
											$filetemplocation = $_FILES['changedimagefile']['tmp_name'];
											$fileextension=@end(@explode('.',$filename));
											$max_width_small=40;
											$max_height_small=40;
											$max_width_big=200;
											$max_height_big=200;
											move_uploaded_file($filetemplocation,'upload/'.$currentuserusername.$filename);
											$filename='upload/'.$currentuserusername.$filename;

											if($fileextension=='jpg'){
												list($width,$height)=getimagesize($filename);
												$ratio_small=min($max_width_small/$width,$max_height_small/$height);
												$ratio_big=min($max_width_big/$width,$max_height_big/$height);
												$new_width_small=ceil($ratio_small*$width);
												$new_height_small=ceil($ratio_small*$height);
												$new_width_big=ceil($ratio_big*$width);
												$new_height_big=ceil($ratio_big*$height);
												$oldimage=imagecreatefromjpeg($filename);
												$newimage_small=imagecreatetruecolor($new_width_small,$new_height_small);
												$newimage_big=imagecreatetruecolor($new_width_big,$new_height_big);
												imagecopyresampled($newimage_small, $oldimage, 0, 0, 0, 0, $new_width_small, $new_height_small, $width, $height);
												imagecopyresampled($newimage_big, $oldimage, 0, 0, 0, 0, $new_width_big, $new_height_big, $width, $height);
												$newlocation_small='uploadsmall/small '.$currentuserusername.$imagename;
												$newlocation_big='uploadbig/big '.$currentuserusername.$imagename;
												header('Content-type:image/jpeg');
												imagejpeg($newimage_small, $newlocation_small, 100);
												//imagejpeg($newimage_small, null, 100);
												imagejpeg($newimage_big, $newlocation_big, 100);
												//imagejpeg($newimage_big, null, 100);
												
												require('connection.php');
												$newlocation_small=mysql_real_escape_string($newlocation_small);
												$newlocation_big=mysql_real_escape_string($newlocation_big);
												$querydeletepreviouspath="delete from ".$_SESSION['username']."photos where name='profilepic'";
												$resultdeletepreviouspath=mysql_query($querydeletepreviouspath);
												$querydeletepreviouspathsmall="delete from ".$_SESSION['username']."photos where name='profilepicsmall'";
												$resultdeletepreviouspathsmall=mysql_query($querydeletepreviouspathsmall);
												if($resultdeletepreviouspath && $resultdeletepreviouspathsmall){
													$queryinsertpath="insert into ".$_SESSION['username']."photos (name,path)values('profilepic','$newlocation_big')";
													$resultinsertpath=mysql_query($queryinsertpath);
													$queryinsertpathsmall="insert into ".$_SESSION['username']."photos (name,path)values('profilepicsmall','$newlocation_small')";
													$resultinsertpathsmall=mysql_query($queryinsertpathsmall);
												}
												
												
												imagedestroy($oldimage);
												imagedestroy($newimage_small);
												imagedestroy($newimage_big);
												header("Refresh: 0; url=account.php");
											}else if($fileextension=='png'){
												list($width,$height)=getimagesize($filename);
												$ratio_small=min($max_width_small/$width,$max_height_small/$height);
												$ratio_big=min($max_width_big/$width,$max_height_big/$height);
												$new_width_small=ceil($ratio_small*$width);
												$new_height_small=ceil($ratio_small*$height);
												$new_width_big=ceil($ratio_big*$width);
												$new_height_big=ceil($ratio_big*$height);
												$oldimage=imagecreatefrompng($filename);
												$newimage_small=imagecreatetruecolor($new_width_small,$new_height_small);
												$newimage_big=imagecreatetruecolor($new_width_big,$new_height_big);
												imagecopyresampled($newimage_small, $oldimage, 0, 0, 0, 0, $new_width_small, $new_height_small, $width, $height);
												imagecopyresampled($newimage_big, $oldimage, 0, 0, 0, 0, $new_width_big, $new_height_big, $width, $height);
												$newlocation_small='uploadsmall/small '.$currentuserusername.$imagename;
												$newlocation_big='uploadbig/big '.$currentuserusername.$imagename;
												header('Content-type:image/png');
												imagepng($newimage_small, $newlocation_small);
												//imagepng($newimage_small, null, 9, PNG_NO_FILTER);
												imagepng($newimage_big, $newlocation_big);
												//imagepng($newimage_big, null, 9, PNG_NO_FILTER);
												
												
												require('connection.php');
												$newlocation_small=mysql_real_escape_string($newlocation_small);
												$newlocation_big=mysql_real_escape_string($newlocation_big);
												$querydeletepreviouspath="delete from ".$_SESSION['username']."photos where name='profilepic'";
												$resultdeletepreviouspath=mysql_query($querydeletepreviouspath);
												$querydeletepreviouspathsmall="delete from ".$_SESSION['username']."photos where name='profilepicsmall'";
												$resultdeletepreviouspathsmall=mysql_query($querydeletepreviouspathsmall);
												if($resultdeletepreviouspath && $resultdeletepreviouspathsmall){
													$queryinsertpath="insert into ".$_SESSION['username']."photos (name,path)values('profilepic','$newlocation_big')";
													$resultinsertpath=mysql_query($queryinsertpath);
													$queryinsertpathsmall="insert into ".$_SESSION['username']."photos (name,path)values('profilepicsmall','$newlocation_small')";
													$resultinsertpathsmall=mysql_query($queryinsertpathsmall);
												}
												imagedestroy($oldimage);
												imagedestroy($newimage_small);
												imagedestroy($newimage_big);
												header("Refresh: 0; url=account.php");
											}else if($fileextension=='gif'){
												list($width,$height)=getimagesize($filename);
												$ratio_small=min($max_width_small/$width,$max_height_small/$height);
												$ratio_big=min($max_width_big/$width,$max_height_big/$height);
												$new_width_small=ceil($ratio_small*$width);
												$new_height_small=ceil($ratio_small*$height);
												$new_width_big=ceil($ratio_big*$width);
												$new_height_big=ceil($ratio_big*$height);
												$oldimage=imagecreatefromgif($filename);
												$newimage_small=imagecreatetruecolor($new_width_small,$new_height_small);
												$newimage_big=imagecreatetruecolor($new_width_big,$new_height_big);
												imagecopyresampled($newimage_small, $oldimage, 0, 0, 0, 0, $new_width_small, $new_height_small, $width, $height);
												imagecopyresampled($newimage_big, $oldimage, 0, 0, 0, 0, $new_width_big, $new_height_big, $width, $height);
												$newlocation_small='uploadsmall/small '.$currentuserusername.$imagename;
												$newlocation_big='uploadbig/big '.$currentuserusername.$imagename;
												header('Content-type:image/gif');
												imagegif($newimage_small, $newlocation_small);
												//imagegif($newimage_small, null);
												imagegif($newimage_big, $newlocation_big);
												//imagegif($newimage_big, null);
												
												require('connection.php');
												$newlocation_small=mysql_real_escape_string($newlocation_small);
												$newlocation_big=mysql_real_escape_string($newlocation_big);
												$querydeletepreviouspath="delete from ".$_SESSION['username']."photos where name='profilepic'";
												$resultdeletepreviouspath=mysql_query($querydeletepreviouspath);
												$querydeletepreviouspathsmall="delete from ".$_SESSION['username']."photos where name='profilepicsmall'";
												$resultdeletepreviouspathsmall=mysql_query($querydeletepreviouspathsmall);
												if($resultdeletepreviouspath && $resultdeletepreviouspathsmall){
													$queryinsertpath="insert into ".$_SESSION['username']."photos (name,path)values('profilepic','$newlocation_big')";
													$resultinsertpath=mysql_query($queryinsertpath);
													$queryinsertpathsmall="insert into ".$_SESSION['username']."photos (name,path)values('profilepicsmall','$newlocation_small')";
													$resultinsertpathsmall=mysql_query($queryinsertpathsmall);
												}
												imagedestroy($oldimage);
												imagedestroy($newimage_small);
												imagedestroy($newimage_big);
												header("Refresh: 0; url=account.php");
											}else{
												echo '<div class="notice">Image is not in jpg,png or gif format.</div>';
											}
										}
									}
									
									
									
									
									if($imagepath==''){
										echo '<img src="upload/anonymous.jpg" /><br/>
										<span id="addprofilepictrigger" style="font-size:13px;text-decoration:underline;cursor:pointer;">Add profile pic</span>
												<form action="account.php" method="post" enctype="multipart/form-data" id="addprofilepicform">
														<input type="file" name="imagefile" /><br/>
														<input type="submit" name="submit" />
												</form>';
									}else{
										echo '<img src="'.$imagepath.'" /><br/>
										<span id="changeremoveprofilepictrigger" style="font-size:13px;text-decoration:underline;cursor:pointer;">Change/Remove profile pic</span>
										<section id="changeremoveprofilepicsection">
											<form action="account.php" method="post" enctype="multipart/form-data">
															<input type="file" name="changedimagefile" /><br/>
															<input type="submit" name="changeprofilepicbutton" value="Change profile pic" />
													</form>
											<form action="account.php" method="post">
													<input type="submit" name="removeprofilepicbutton" value="Remove profile pic" />
											</form>
										</section>';
									}
								
							?>
						<script type="text/javascript" src="js/jquery.js"></script>
						<script type="text/javascript">
							$(document).ready(function(){
								$('#changeremoveprofilepicsection').hide();
								$('#changeremoveprofilepictrigger').click(function(){
									$('#changeremoveprofilepictrigger').html(function(){
										$('#changeremoveprofilepictrigger').hide();
										$('#changeremoveprofilepicsection').slideDown();
									});
								});
								
								$('#addprofilepicform').hide();
								$('#addprofilepictrigger').click(function(){
									$('#addprofilepictrigger').html(function(){
										$('#addprofilepictrigger').hide();
										$('#addprofilepicform').slideDown();
									});
								});
								$('.deletepost').hide();
								$('.deleteposttrigger').hover(function(){
									$(this).css('cursor','pointer');
								});
								$('.deleteposttrigger').click(function(){
									$(this).hide();
									$(this).siblings('.deletepost').fadeIn('fast');
								});
								$('.nodeletebutton').click(function(){
									$(this).parent().parent().hide();
									$(this).parent().parent().siblings('.deleteposttrigger').show();
								});
								$('.deletecomment').hide();
								$('.deletecommenttrigger').hover(function(){
									$(this).css('cursor','pointer');
								});
								$('.deletecommenttrigger').click(function(){
									$(this).hide();
									$(this).siblings('.deletecomment').fadeIn('fast');
								});
								$('.nodeletebuttoncomment').click(function(){
									$(this).parent().parent().hide();
									$(this).parent().parent().siblings('.deletecommenttrigger').show();
								});
							});
						</script>
						
						</td></tr>
						
							<tr>
								<td><a href="account.php" >Home</a></td>
							</tr>
							<tr>
								<td><a href="friends.php" >Friends</a></td>
							</tr>
							<tr>
								<td><a href="#" >Posts</a></td>
							</tr>
							<tr>
								<td><a href="#" >Notifications</a></td>
							</tr>
							<tr>
								<td><a href="accountsettings.php" >Account Settings</a></td>
							</tr>
							<tr>
								<td><a href="account.php" style="font-size:14px;text-decoration:underline;color:maroon;">Refresh this page</a></td>
							</tr>
						</table>
					
					<div id="notifications">Friend Requests:<br/>
						<?php
							if(isset($_POST['hiddenfriendusername'])){
								$hiddenfriendusername=$_POST['hiddenfriendusername'];
								require('connection.php');
									$queryaddfriend="insert into ".$_SESSION['username']."friends (friendusername,friendfname,friendlname,friendemail) select friendrequestusername,friendrequestfirstname,friendrequestlastname,friendrequestemail from ".$_SESSION['username']."friendrequests where friendrequestusername='$hiddenfriendusername'";
									$resultaddfriend=mysql_query($queryaddfriend);
									$querydeletefriendfromfriendrequesttable="delete from ".$_SESSION['username']."friendrequests where friendrequestusername='$hiddenfriendusername'";
									$resultdeletefriendfromfriendrequesttable=mysql_query($querydeletefriendfromfriendrequesttable);
									$queryaddfriendinothertable="insert into ".$hiddenfriendusername."friends (friendusername,friendfname,friendlname,friendemail)values('$currentuserusername','$currentuserfirstname','$currentuserlastname','$currentuseremail')";
									$resultaddfriendinothertable=mysql_query($queryaddfriendinothertable);
									if($resultaddfriend){
										echo '<span class="notice">Request accepted.</span><br/>';
										header("Refresh: 0; url=account.php");
									}else{
										echo '<span class="notice">Some error occured while accepting friend request.</span>';
									}

							}
							require('connection.php');
							$queryretrievefriendrequests="select * from ".$_SESSION['username']."friendrequests";
							$resultretrievefriendrequests=mysql_query($queryretrievefriendrequests);
							if($resultretrievefriendrequests){
								if(mysql_num_rows($resultretrievefriendrequests)==0){
									echo '<br/><span class="notice">No friend requests.</span>';
								}else{
									while($arrayfriendrequests=mysql_fetch_assoc($resultretrievefriendrequests)){
										echo '<div class="singlefrienddiv" style="width:200px;">Name: '.$arrayfriendrequests['friendrequestfirstname'].' '.$arrayfriendrequests['friendrequestlastname'].'<br/>
											Username: '.$arrayfriendrequests['friendrequestusername'].'<br/>Email: '.$arrayfriendrequests['friendrequestemail'].'
											<form method="post" action="account.php">
											<input type="submit" name="addfriendbutton" name="addfriendbutton" value="Accept" />
											<input type="hidden" name="hiddenfriendusername" id="hiddenfriendusername" value="'.$arrayfriendrequests['friendrequestusername'].'" />
											</form>
											</div>';
									}
								}
							}else{
								echo '<span class="notice">Some error occured while retrieving friend requests.</span>';
							}

						?>
					</div>
					<div style="float:left;">
						<form class="posts" name="postform" id="postform"  action="account.php" method="post">
						<?php
							if(isset($_POST['postbutton'])){
								$post=$_POST['post'];
								if(!empty($post)){
									require('connection.php');
									$post=mysql_real_escape_string(nl2br(htmlentities($post)));
									$querypost="insert into ".$_SESSION['username']."posts (post,postby,datetime)values('$post','".$_SESSION['username']."','$date')";
									$resultpost=mysql_query($querypost);
									if($resultpost){
										//echo '<span class="notice">Post successful!</span>';
									}else{
										echo '<span class="notice">Some error occured while posting.</span>';
									}
								}else{
									echo '<span class="notice">Please enter a post first.</span>';
								}
							}
						?>
							<p>Status today: <br/><textarea placeholder="What's your status" cols="60" rows="3" style="overflow:auto;resize:none;" id="post" name="post"></textarea><br/>
							<input type="submit" name="postbutton" id="postbutton" value="Post" /></p>
						</form>
						
						
						<?php
						require('connection.php');
						
						$queryretrivefriends="select * from ".$_SESSION['username']."friends";
						$resultretrivefriends=mysql_query($queryretrivefriends);
						if($resultretrivefriends){
							if(mysql_num_rows($resultretrivefriends)!=0){
								$i=0;
								while($arrayfriend=mysql_fetch_assoc($resultretrivefriends)){
									$friendusername=$arrayfriend['friendusername'];
									$queryretrievefriendposts[$i]="select * from ".$friendusername."posts";
									$i++;
								}
								$sizeofarray=count($queryretrievefriendposts);
								$newqueryretrievefriendposts="";
								for($j=0;$j<$sizeofarray;$j++){
									$newqueryretrievefriendposts=$newqueryretrievefriendposts.$queryretrievefriendposts[$j]." union all ";
								}
								$newqueryretrievefriendposts=$newqueryretrievefriendposts."select * from ".$_SESSION['username']."posts";
								$newqueryretrievefriendposts=$newqueryretrievefriendposts." order by datetime desc";
								$resultretrievefriendposts=mysql_query($newqueryretrievefriendposts);
								if($resultretrievefriendposts){
									if(mysql_num_rows($resultretrievefriendposts)!=0){
										while($arraypost=mysql_fetch_assoc($resultretrievefriendposts)){

											//create view
											$querycreateview="create view newview as ".$newqueryretrievefriendposts;
											$resultcreateview=mysql_query($querycreateview);

											//retrieve post
											$postretrieved=$arraypost['post'];
											$postidretrieved=$arraypost['id'];
											$postbyretrieved=$arraypost['postby'];
											
											//retrive post by full name
											$queryretrivename="select * from usernamepassword where username='".$postbyretrieved."'";
											$resultretrivename=mysql_query($queryretrivename);
											if($resultretrivename){
												if(mysql_num_rows($resultretrivename)==1){
													$arraynameofpostby=mysql_fetch_assoc($resultretrivename);
													$firstnameofpostby=$arraynameofpostby['firstname'];
													$lastnameofpostby=$arraynameofpostby['lastname'];
												}
											}
												// query for retrieving small profile pic
											$queryretrievefriendprofilepic="select * from ".$postbyretrieved."photos where name='profilepicsmall'";
											$resultretrievefriendprofilepic=mysql_query($queryretrievefriendprofilepic);
											if($resultretrievefriendprofilepic){
												if(mysql_num_rows($resultretrievefriendprofilepic)==1){
													$arrayretrievefriendprofilepic=mysql_fetch_assoc($resultretrievefriendprofilepic);
													$profilepicsmallpath=$arrayretrievefriendprofilepic['path'];
												}else{
													$profilepicsmallpath='';
												}
											}
											
											$postretrieved=mysql_real_escape_string($postretrieved);
											$arraydate=mysql_fetch_array(mysql_query("select date_format( datetime,'%d-%m-%y' ) FROM newview where post='$postretrieved'"));
											$arraytime=mysql_fetch_array(mysql_query("select time_format( datetime,'%r' ) FROM newview where post='$postretrieved'"));
											echo '<div class="posts">';
											if($postbyretrieved==$_SESSION['username']){
												echo '<div class="deletepostsection">
												<span class="deleteposttrigger">Delete Post</span>
												<div class="deletepost">
												<span class="areyousuretext">Are you sure you want to delete this post?</span><br/>
												<form method="post" action="account.php" style="float:right;">
												<input type="hidden" value="'.$postidretrieved.'" name="posttodeleteid" />
												<input type="submit" value="Yes" name="yesdeletebutton'.$postidretrieved.'" />
												<input type="button" value="No" class="nodeletebutton" />
												</form>
												</div>
												</div>';
											}
											if($profilepicsmallpath==''){echo '<span class="byusername">'.$firstnameofpostby.' '.$lastnameofpostby.'</span>';}else{echo '<img src="'.$profilepicsmallpath.'" />  <span class="byusername">'.$firstnameofpostby.' '.$lastnameofpostby.'</span>';}
											echo '<br/><br/>'.$arraypost['post'];
											echo '<br/><span class="datetime">'.$arraydate[0].'<span style="margin-left:5px;"></span>'.$arraytime[0].'</span>
											<div class="comment">
												';
											// <form id="commentform" name="commentform" action="account.php" method="post"> this is now below somewhere
											
												echo '<div id="commentsuccessful">';
														if(isset($_POST['commentbutton'.$postidretrieved]) && isset($_POST['postby'.$postbyretrieved])){
															$comment=$_POST['comment'];
															$comment=mysql_real_escape_string(nl2br(htmlentities($comment)));
															$postid=$_POST['postid'];
															$postby=$_POST['postby'.$postbyretrieved];
															if(!empty($comment)){
																require('connection.php');
																$querycomment="insert into ".$_SESSION['username']."comments (postid,postby,commentby,comment,datetime)values('$postid','$postby','".$_SESSION['username']."','$comment','$date')";
																$resultcomment=mysql_query($querycomment);
																if($resultcomment){
																	//echo '<br/><span class="notice">Comment posted successfully!</span>';
																	
																}else{
																	echo '<span class="notice">There occured a error while posting comment</span>';
																}
															}else{
																echo '<span class="notice">Please write a comment first.</span>';
															}
														}
													echo '</div>';
												
													echo '<span style="color:black;text-decoration:underline;text-shadow:1px 1px 1px white;">Comments:</span><br/>';




													//retrieve comment
													$queryretrivefriends="select * from ".$_SESSION['username']."friends";
													$resultretrivefriends=mysql_query($queryretrivefriends);
													if($resultretrivefriends){
														if(mysql_num_rows($resultretrivefriends)!=0){
															$i=0;
															while($arrayfriend=mysql_fetch_assoc($resultretrivefriends)){
																$friendusername=$arrayfriend['friendusername'];
																$queryretrievefriendcomments[$i]="select * from ".$friendusername."comments";
																$i++;
															}
															$sizeofarray=count($queryretrievefriendcomments);
															$newqueryretrievefriendcomments="";
															for($j=0;$j<$sizeofarray;$j++){
																$newqueryretrievefriendcomments=$newqueryretrievefriendcomments.$queryretrievefriendcomments[$j]." union all ";
															}
															$newqueryretrievefriendcomments=$newqueryretrievefriendcomments."select * from ".$_SESSION['username']."comments";
															$resultretrievefriendcomments=mysql_query($newqueryretrievefriendcomments);
															if($resultretrievefriendcomments){
																if(mysql_num_rows($resultretrievefriendcomments)!=0){
																	//while($arraycomment=mysql_fetch_assoc($resultretrievefriendcomments)){

																		//create view newviewforcomments
																		$querycreateviewforcomments="create view newviewforcomments as ".$newqueryretrievefriendcomments;
																		$resultcreateviewforcomments=mysql_query($querycreateviewforcomments);

																		$queryforretrievingspecificcomment="select * from newviewforcomments where postid='$postidretrieved' and postby='$postbyretrieved' order by datetime asc";
																		$resultforretrievingspecificcomment=mysql_query($queryforretrievingspecificcomment);
																		if($resultforretrievingspecificcomment){
																			if(mysql_num_rows($resultforretrievingspecificcomment)!=0){
																				while($arraycommentretrieved=mysql_fetch_assoc($resultforretrievingspecificcomment)){
																					$commentretrieved=$arraycommentretrieved['comment'];
																					$commentbyretrieved=$arraycommentretrieved['commentby'];
																					$commentidretrieved=$arraycommentretrieved['id'];
																					
																					//retrive comment by full name
																					$queryretrivename="select * from usernamepassword where username='".$commentbyretrieved."'";
																					$resultretrivename=mysql_query($queryretrivename);
																					if($resultretrivename){
																						if(mysql_num_rows($resultretrivename)==1){
																							$arraynameofcommentby=mysql_fetch_assoc($resultretrivename);
																							$firstnameofcommentby=$arraynameofcommentby['firstname'];
																							$lastnameofcommentby=$arraynameofcommentby['lastname'];
																						}
																					}
																						// query for retrieving small profile pic for comments
																					$queryretrievefriendprofilepicforcomment="select * from ".$commentbyretrieved."photos where name='profilepicsmall'";
																					$resultretrievefriendprofilepicforcomment=mysql_query($queryretrievefriendprofilepicforcomment);
																					if($resultretrievefriendprofilepicforcomment){
																						if(mysql_num_rows($resultretrievefriendprofilepicforcomment)==1){
																							$arrayretrievefriendprofilepicforcomment=mysql_fetch_assoc($resultretrievefriendprofilepicforcomment);
																							$profilepicsmallpathforcomment=$arrayretrievefriendprofilepicforcomment['path'];
																						}else{
																							$profilepicsmallpathforcomment='';
																						}
																					}
																					
																					$commentretrieved=mysql_real_escape_string($commentretrieved);
																					$arraycommentdate=mysql_fetch_array(mysql_query("select date_format(datetime,'%d-%m-%y') from newviewforcomments where comment='$commentretrieved'"));
																					$arraycommenttime=mysql_fetch_array(mysql_query("select time_format(datetime,'%r') from newviewforcomments where comment='$commentretrieved'"));
																					echo '<div class="singlecomment">';
																					if($commentbyretrieved==$_SESSION['username']){
																					echo '<div class="deletecommentsection">
																					<span class="deletecommenttrigger">Delete Comment</span>
																					<div class="deletecomment">
																					<span class="areyousuretextcomment">Are you sure you want to delete this comment?</span><br/>
																					<form method="post" action="account.php" style="float:right;">
																					<input type="hidden" value="'.$commentbyretrieved.'" name="commenttodeleteby'.$commentbyretrieved.'" />
																					<input type="hidden" value="'.$commentidretrieved.'" name="commenttodeleteid'.$commentidretrieved.'" />
																					<input type="hidden" value="'.$postidretrieved.'" name="commenttodeletepostid'.$postidretrieved.'" />
																					<input type="hidden" value="'.$postbyretrieved.'" name="commenttodeletepostby'.$postbyretrieved.'" />
																					<input type="submit" value="Yes" name="yesdeletebuttoncomment'.$commentidretrieved.'" />
																					<input type="button" value="No" class="nodeletebuttoncomment" />
																					</form>
																					</div>
																					</div>';
																					}
																					
																					ob_start();
																					if($profilepicsmallpathforcomment==''){echo '<span class="commentbyusername">'.$firstnameofcommentby.' '.$lastnameofcommentby.'</span>';}else{echo '<img src="'.$profilepicsmallpathforcomment.'" />  <span class="commentbyusername">'.$firstnameofcommentby.' '.$lastnameofcommentby.'</span>';}
																					echo '<br/>'.$arraycommentretrieved['comment'].'';
																					echo '<br/><span class="datetime">'.$arraycommentdate[0].'<span style="margin-left:5px;"></span>'.$arraycommenttime[0].'</span>
																					</div>';
																					
																					// deleting a comment
																					if(isset($_POST['commenttodeleteby'.$commentbyretrieved]) && isset($_POST['commenttodeleteid'.$commentidretrieved]) && isset($_POST['commenttodeletepostid'.$postidretrieved]) && isset($_POST['commenttodeletepostby'.$postbyretrieved]) && isset($_POST['yesdeletebuttoncomment'.$commentidretrieved])){
																						$commenttodeleteby=@$_POST['commenttodeleteby'].$commentbyretrieved;
																						$commenttodeleteid=@$_POST['commenttodeleteid'].$commentidretrieved;
																						$commenttodeletepostid=@$_POST['commenttodeletepostid'].$postidretrieved;
																						$commenttodeletepostby=@$_POST['commenttodeletepostby'].$postbyretrieved;
																						$querydeletecomment="delete from ".$_SESSION['username']."comments where id='$commenttodeleteid' and postid='$commenttodeletepostid' and postby='$commenttodeletepostby' and commentby='$commenttodeleteby'";
																						$resultdeletecomment=mysql_query($querydeletecomment);
																						header("Refresh: 0; url=account.php");
																					}
																				}
																			}
																		}else{
																			echo '<span class="notice">Some error occured while retrieving specific comment.</span>';
																		}
																	//}


																}
															}else{
																echo '<span class="notice">Some error occured while retrieving friends comment.</span>';
															}

														}


													}else{
														echo '<span class="notice">Some error occured while retrieving friends.</span>';
													}
													///retrieve comment close
													
													echo '<form id="commentform" name="commentform" action="account.php" method="post">
													<textarea id="comment" name="comment" rows="2" cols="30" style="overflow:auto;resize:none;" placeholder="Write comment here as '.$_SESSION['username'].'"></textarea>
													<br/><input type="submit" id="commentbutton" name="commentbutton'.$postidretrieved.'" value="Comment" />
													<input type="hidden" name="postid" value="'.$postidretrieved.'" />
													<input type="hidden" name="postby'.$postbyretrieved.'" value="'.$postbyretrieved.'" />';
													

											echo '</form>
											</div>
											</div>';
											
											//deleting a post
											if(isset($_POST['yesdeletebutton'.$postidretrieved])){
												$posttodeleteid=$_POST['posttodeleteid'];
												$querydeletepost="delete from ".$_SESSION['username']."posts where id='$posttodeleteid'";
												$resultdeletepost=mysql_query($querydeletepost);
												header("Refresh: 0; url=account.php");
											}
										
											mysql_query("drop view newview");
											mysql_query("drop view newviewforcomments");
										}
										
									}
								}else{
									echo '<span class="notice">Some error occured while retrieving friends post.</span>';
								}

							}else{
								// if no friend
								$queryretrivemyposts="select * from ".$_SESSION['username']."posts order by datetime desc";
								$resultretrivemyposts=mysql_query($queryretrivemyposts);
								if($resultretrivemyposts){
									if(mysql_num_rows($resultretrivemyposts)!=0){
										while($arraymyposts=mysql_fetch_assoc($resultretrivemyposts)){
											//retrieve mypost
											$postretrieved=$arraymyposts['post'];
											$postidretrieved=$arraymyposts['id'];
											$postbyretrieved=$arraymyposts['postby'];
											//retrive post by full name
											$queryretrivename="select * from usernamepassword where username='".$postbyretrieved."'";
											$resultretrivename=mysql_query($queryretrivename);
											if($resultretrivename){
												if(mysql_num_rows($resultretrivename)==1){
													$arraynameofpostby=mysql_fetch_assoc($resultretrivename);
													$firstnameofpostby=$arraynameofpostby['firstname'];
													$lastnameofpostby=$arraynameofpostby['lastname'];
												}
											}
												// query for retrieving small profile pic if no friend
											$queryretrievefriendprofilepicmyposts="select * from ".$postbyretrieved."photos where name='profilepicsmall'";
											$resultretrievefriendprofilepicmyposts=mysql_query($queryretrievefriendprofilepicmyposts);
											if($resultretrievefriendprofilepicmyposts){
												if(mysql_num_rows($resultretrievefriendprofilepicmyposts)==1){
													$arrayretrievefriendprofilepicmyposts=mysql_fetch_assoc($resultretrievefriendprofilepicmyposts);
													$profilepicsmallpathmyposts=$arrayretrievefriendprofilepicmyposts['path'];
												}else{
													$profilepicsmallpathmyposts='';
												}
											}
											
											
											$postretrieved=mysql_real_escape_string($postretrieved);
											$arraydate=mysql_fetch_array(mysql_query("select date_format( datetime,'%d-%m-%y' ) FROM ".$_SESSION['username']."posts where post='$postretrieved'"));
											$arraytime=mysql_fetch_array(mysql_query("select time_format( datetime,'%r' ) FROM ".$_SESSION['username']."posts where post='$postretrieved'"));
											echo '<div class="posts">';
											if($postbyretrieved==$_SESSION['username']){
												echo '<div class="deletepostsection">
												<span class="deleteposttrigger">Delete Post</span>
												<div class="deletepost">
												<span class="areyousuretext">Are you sure you want to delete this post?</span><br/>
												<form method="post" action="account.php" style="float:right;">
												<input type="hidden" value="'.$postidretrieved.'" name="posttodeleteid" />
												<input type="submit" value="Yes" name="yesdeletebutton'.$postidretrieved.'" />
												<input type="button" value="No" class="nodeletebutton" />
												</form>
												</div>
												</div>';
											}
											
											ob_start();
											if($profilepicsmallpathmyposts==''){echo '<span class="byusername">'.$firstnameofpostby.' '.$lastnameofpostby.'</span>';}else{echo '<img src="'.$profilepicsmallpathmyposts.'" />  <span class="byusername">'.$firstnameofpostby.' '.$lastnameofpostby.'</span>';}
											echo '<br/><br/>'.$arraymyposts['post'].'';
											echo '<br/><span class="datetime">'.$arraydate[0].'<span style="margin-left:5px;"></span>'.$arraytime[0].'</span>
											<div class="comment">
												'; //<form id="commentform" name="commentform" action="account.php" method="post"> this is now somewhere below
												
													echo '<div id="commentsuccessful">';
														if(isset($_POST['commentbutton'.$postidretrieved]) && isset($_POST['postby'.$postbyretrieved])){
															$comment=$_POST['comment'];
															$comment=mysql_real_escape_string(nl2br(htmlentities($comment)));
															$postid=$_POST['postid'];
															$postby=$_POST['postby'.$postbyretrieved];
															if(!empty($comment)){
																require('connection.php');
																$querycomment="insert into ".$_SESSION['username']."comments (postid,postby,commentby,comment,datetime)values('$postid','$postby','".$_SESSION['username']."','$comment','$date')";
																$resultcomment=mysql_query($querycomment);
																if($resultcomment){
																	//echo '<br/><span class="notice">Comment posted successfully!</span>';
																}else{
																	echo '<span class="notice">There occured a error while posting comment</span>';
																}
															}else{
																echo '<span class="notice">Please write a comment first.</span>';
															}
														}
													echo '</div>';
													
													echo '<span style="color:black;text-decoration:underline;text-shadow:1px 1px 1px white;">Comments:</span><br/>';
													
													
													
													
													

													//retrieve mycomments
													$queryretrievemycomments="select * from ".$_SESSION['username']."comments where postid='$postidretrieved' and postby='$postbyretrieved' order by datetime asc";
													$resultretrievemycomments=mysql_query($queryretrievemycomments);
													if($resultretrievemycomments){
														if(mysql_num_rows($resultretrievemycomments)!=0){
															while($arraymycomments=mysql_fetch_assoc($resultretrievemycomments)){
																$mycommentretrieved=$arraymycomments['comment'];
																$mycommentretrieved=mysql_real_escape_string($mycommentretrieved);
																$mycommentbyretrieved=$arraymycomments['commentby'];
																$mycommentidretrieved=$arraymycomments['id'];
																//retrive comment by full name
																$queryretrivename="select * from usernamepassword where username='".$mycommentbyretrieved."'";
																$resultretrivename=mysql_query($queryretrivename);
																if($resultretrivename){
																	if(mysql_num_rows($resultretrivename)==1){
																		$arraynameofcommentby=mysql_fetch_assoc($resultretrivename);
																		$firstnameofcommentby=$arraynameofcommentby['firstname'];
																		$lastnameofcommentby=$arraynameofcommentby['lastname'];
																	}
																}
																	// query for retrieving small profile pic for comments
																$queryretrievefriendprofilepicformycomment="select * from ".$mycommentbyretrieved."photos where name='profilepicsmall'";
																$resultretrievefriendprofilepicformycomment=mysql_query($queryretrievefriendprofilepicformycomment);
																if($resultretrievefriendprofilepicformycomment){
																	if(mysql_num_rows($resultretrievefriendprofilepicformycomment)==1){
																		$arrayretrievefriendprofilepicformycomment=mysql_fetch_assoc($resultretrievefriendprofilepicformycomment);
																		$profilepicsmallpathformycomment=$arrayretrievefriendprofilepicformycomment['path'];
																	}else{
																		$profilepicsmallpathformycomment='';
																	}
																}
																
																
																$arraycommentdate=mysql_fetch_array(mysql_query("select date_format(datetime,'%d-%m-%y') from ".$_SESSION['username']."comments where comment='$mycommentretrieved'"));
																$arraycommenttime=mysql_fetch_array(mysql_query("select time_format(datetime,'%r') from ".$_SESSION['username']."comments where comment='$mycommentretrieved'"));
																echo '<div class="singlecomment">';
																if($mycommentbyretrieved==$_SESSION['username']){
																echo '<div class="deletecommentsection">
																<span class="deletecommenttrigger">Delete Comment</span>
																<div class="deletecomment">
																<span class="areyousuretextcomment">Are you sure you want to delete this comment?</span><br/>
																<form method="post" action="account.php" style="float:right;">
																<input type="hidden" value="'.$mycommentbyretrieved.'" name="commenttodeleteby'.$mycommentbyretrieved.'" />
																<input type="hidden" value="'.$mycommentidretrieved.'" name="commenttodeleteid'.$mycommentidretrieved.'" />
																<input type="hidden" value="'.$postidretrieved.'" name="commenttodeletepostid'.$postidretrieved.'" />
																<input type="hidden" value="'.$postbyretrieved.'" name="commenttodeletepostby'.$postbyretrieved.'" />
																<input type="submit" value="Yes" name="yesdeletebuttoncomment'.$mycommentidretrieved.'" />
																<input type="button" value="No" class="nodeletebuttoncomment" />
																</form>
																</div>
																</div>';
																}
																
																if($profilepicsmallpathformycomment==''){echo '<span class="commentbyusername">'.$firstnameofcommentby.' '.$lastnameofcommentby.'</span>';}else{echo '<img src="'.$profilepicsmallpathformycomment.'" />  <span class="commentbyusername">'.$firstnameofcommentby.' '.$lastnameofcommentby.'</span>';}
																echo '<br/>'.$arraymycomments['comment'];
																echo '<br/><span class="datetime">'.$arraycommentdate[0].'<span style="margin-left:5px;"></span>'.$arraycommenttime[0].'</span>
																</div>';
																
																//deleting a comment
																if(isset($_POST['commenttodeleteby'.$mycommentbyretrieved]) && isset($_POST['commenttodeleteid'.$mycommentidretrieved]) && isset($_POST['commenttodeletepostid'.$postidretrieved]) && isset($_POST['commenttodeletepostby'.$postbyretrieved]) && isset($_POST['yesdeletebuttoncomment'.$mycommentidretrieved])){
																	$commenttodeleteby=@$_POST['commenttodeleteby'].$mycommentbyretrieved;
																	$commenttodeleteid=@$_POST['commenttodeleteid'].$mycommentidretrieved;
																	$commenttodeletepostid=@$_POST['commenttodeletepostid'].$postidretrieved;
																	$commenttodeletepostby=@$_POST['commenttodeletepostby'].$postbyretrieved;
																	$querydeletecomment="delete from ".$_SESSION['username']."comments where id='$commenttodeleteid' and postid='$commenttodeletepostid' and postby='$commenttodeletepostby' and commentby='$commenttodeleteby'";
																	$resultdeletecomment=mysql_query($querydeletecomment);
																	header("Refresh: 0; url=account.php");
																}
															}
															
															
															
														}
													}else{
														echo '<span class="notice">Some error occured while retrieving mycomments.</span>';
													}
													//retrieve mycomments close
						
													echo '<form id="commentform" name="commentform" action="account.php" method="post">
													<textarea id="comment" name="comment" rows="2" cols="30" style="overflow:auto;resize:none;" placeholder="Write comment here as '.$_SESSION['username'].'"></textarea>
													<br/><input type="submit" id="commentbutton" name="commentbutton'.$postidretrieved.'" value="Comment" />
													<input type="hidden" name="postid" value="'.$postidretrieved.'" />
													<input type="hidden" name="postby'.$postbyretrieved.'" value="'.$postbyretrieved.'" />';
													

											echo '</form>
											</div></div>';
											//deleting a post
											if(isset($_POST['yesdeletebutton'.$postidretrieved])){
												$posttodeleteid=$_POST['posttodeleteid'];
												$querydeletepost="delete from ".$_SESSION['username']."posts where id='$posttodeleteid'";
												$resultdeletepost=mysql_query($querydeletepost);
												header("Refresh: 0; url=account.php");
											}
										}
										
									}else{
										echo '<span class="notice">No posts till date.</span>';
									}
								}else{
									echo '<span class="notice">Some error occured while retrieving myposts</span>';
								}

							}

						}else{
							echo '<span class="notice">Some error occured while retrieving friends.</span>';
						}


					echo '</div>';
					
					
				}else{
					echo '<span class="notice">Please login first.
					<span class="shortlink"><a href="index.php">Login</a></span></span>';
				}
			?>

		</section>

<?php require('footer.php') ?>