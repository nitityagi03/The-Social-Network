<?php ob_start(); ?>
<?php require('header.php') ?>
		<section id="whiteSpace" style="height:500px;">
			<div id="left">
				Connect with your friends.<br/>
				Register now.
			</div>
			<div id="right">
				<?php
					session_start();
					if(isset($_SESSION['username'])){
						echo '<div class="notice">You are already logged in '.$_SESSION['username'].'<div class="shortlink"><a href="logout.php">Logout first </a></div>or <div class="shortlink"><a href="account.php">Go to your account section.</a></div></div>';
					}else{
						if(isset($_POST['login'])){
							require('connection.php');
							$username=$_POST['username'];
							$username=mysql_real_escape_string(htmlentities(strtolower($username)));
							$password=$_POST['password'];
							$password=mysql_real_escape_string(htmlentities($password));
							if(!empty($username) && !empty($password)){
								$query="select * from usernamepassword where username='$username' and password='$password'";
								$result=mysql_query($query);
								if($result){
									if(mysql_num_rows($result)==1){
										$_SESSION['username']=$username;
										header('Location:account.php');
									}else{
										echo '<span class="notice">Username and password incorrect.</span>';
									}
								}else{
									echo '<span class="notice">Sorry some error occured while retrieving query.</span>';
								}
							}else{
								echo '<span class="notice">Please enter both username and password.</span>';
							}
						}
						echo'<form id="loginform" name="loginform" action="index.php" method="post">
							<p>Username: <input type="text" name="username" id="username" /></p>
							<p>Password: <input type="password" name="password" id="password" /></p>
							<p><input type="submit" value="Login" name="login" id="login" /></p>
							<p class="shortlink" style="font-size:12px;"><a href="forgotpassword.php">Forgot Password?</a></p>
							<p class="shortlink"><a href="register.php">Register</a></p>
						</form>';
					}
				?>
				
			</div>
		</section>

<?php require('footer.php') ?>