		<footer>
			<div id="messagetoall">If you encounter any type of error or some warning or notice, please let me know at Sharstiagarwal2207@gmail.com. 
			You can also send feedback, suggestions or any query at the same.
			</div>
			<div id="developedBy">
				The Social Network<br/>
				
				Developed By - Shristi Agarwal
			</div>
		</footer>
	</body>
</html>