<?php ob_start(); ?>
<?php require('header.php') ?>
		<section id="whiteSpace" style="height:500px;">
		
		<?php
			session_start();
			if(!isset($_SESSION['username'])){
				require('connection.php');
				if(isset($_POST['sendfplinkbutton'])){
					$emailidtosentfplink=mysql_real_escape_string(htmlentities(strtolower($_POST['emailidtosentfplink'])));
					if(!empty($emailidtosentfplink)){
						$querycheckemailid="select * from usernamepassword where email='$emailidtosentfplink'";
						$resultcheckemailid=mysql_query($querycheckemailid);
						if($resultcheckemailid){
							if(mysql_num_rows($resultcheckemailid)==1){
								$arrayuserdetails=mysql_fetch_assoc($resultcheckemailid);
								$password=$arrayuserdetails['password'];
								$to=$emailidtosentfplink;
								$subject='Password for your account at The Social Network';
								$message="Your password is $password";
								if(mail($to,$subject,$message)){
									echo '<span class="notice">Password has been sent to your registered email id.</span>';
								}else{
									echo '<span class="notice">Sorry some error occured while mailing password. Try again or report to webmaster at sharstiagarwal2207@gmail.com.</span>';
								}
							}else{
								echo '<span class="notice">This email id is not registered with us. Please enter registered email id.</span>';
							}
						}
					}else{
						echo '<span class="notice">Please enter a email id first.</span>';
					}
				}
				echo '<form action="forgotpassword.php" method="post">
				<p>Enter your registered email id: <input type="text" name="emailidtosentfplink" size="30" /></p>
				<p><input type="submit" name="sendfplinkbutton" value="Send link to my email id"/></p>
				</form>';
			}else{
				echo '<span class="notice">Please logout first to use forgot password feature. <span class="shortlink"><a href="logout.php">Logout</a></span></span>';
			}
		
		?>
		
		</section>

<?php require('footer.php') ?>