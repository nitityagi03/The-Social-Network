<?php ob_start(); ?>
<?php require('header.php') ?>

		<section id="whiteSpace" style="height:600px;">
			<?php
				session_start();
				if(session_destroy()){
					echo '<span class="notice">You have been successfully logged out. <span class="shortlink"><a href="index.php">Login again.</a></span></span>';
				}else{
					echo '<span class="notice">Sorry some error occured.</span>';
				}
			?>
		</section>

<?php require('footer.php') ?>