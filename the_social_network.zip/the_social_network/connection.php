<?php
	$connect=@mysql_connect('localhost','root','');
	$database=@mysql_select_db('socialnetwork',$connect);
?>