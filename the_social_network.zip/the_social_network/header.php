<!doctype >
<html>
	<title>The Social Network</title>
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<body>
		<header>
			<div id="logo">The Social Network</div>
		</header>