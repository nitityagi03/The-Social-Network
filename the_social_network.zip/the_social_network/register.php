<?php ob_start(); ?>
<?php require('header.php') ?>

		<section id="whiteSpace" style="height:500px;">
		<script type="text/javascript">
			function validation()
			{
			var x=document.forms["registerform"]["email"].value;
			var atpos=x.indexOf("@");
			var dotpos=x.lastIndexOf(".");
			if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
			{
			alert("Please enter a valid e-mail address");
			return false;
			}

			}
		</script>
			<div id="registerspace">
				<?php
					if(isset($_POST['register'])){
						require('connection.php');
						$firstname=mysql_real_escape_string(htmlentities($_POST['firstname']));
						$lastname=mysql_real_escape_string(htmlentities($_POST['lastname']));
						$email=mysql_real_escape_string(htmlentities(strtolower($_POST['email'])));
						$dusername=mysql_real_escape_string(htmlentities(strtolower($_POST['dusername'])));
						$password=mysql_real_escape_string(htmlentities($_POST['password']));
						$cpassword=mysql_real_escape_string(htmlentities($_POST['cpassword']));
						
						if(!empty($firstname) && !empty($lastname) && !empty($email) && !empty($dusername) && !empty($password) && !empty($cpassword)){
							if($password!=$cpassword){
								echo '<span class="notice">Passwords do not match.</span>';
							}else{
								$query="select * from usernamepassword where username='$dusername'";
								$result=mysql_query($query);
								if($result){
									if(mysql_num_rows($result)==0){
										$querycheckemail="select * from usernamepassword where email='$email'";
										$resultcheckemail=mysql_query($querycheckemail);
										if($resultcheckemail){
											if(mysql_num_rows($resultcheckemail)==0){
												//$rand=md5(rand());
												$query2="insert into usernamepassword (firstname,lastname,email,username,password)values('$firstname','$lastname','$email','$dusername','$password')";
												$result2=mysql_query($query2);
												//var_dump($result2);exit;
												$query3="create table ".$dusername."comments (id smallint primary key auto_increment,postid smallint,postby varchar(100),commentby varchar(100),comment text,datetime datetime)";
												$result3=mysql_query($query3);
												$query4="create table ".$dusername."posts (id smallint primary key auto_increment,post text,postby varchar(100),datetime datetime)";
												$result4=mysql_query($query4);
												$query5="create table ".$dusername."friends (id smallint primary key auto_increment,friendusername varchar(255),friendfname varchar(255),friendlname varchar(255),friendemail varchar(255))";
												$result5=mysql_query($query5);
												$query6="create table ".$dusername."friendrequests (id smallint primary key auto_increment,friendrequestfirstname varchar(100),friendrequestlastname varchar(100),friendrequestusername varchar(100),friendrequestemail varchar(100))";
												$result6=mysql_query($query6);
												$query7="create table ".$dusername."photos (id smallint primary key auto_increment,name varchar(255),path varchar(255))";
												$result7=mysql_query($query7);
												/*$to=$email;
												$subject='Email Verification - The Social Network';
												$message="Please enter the link below in your address bar to verify your email id for your registration at The Social Network  
												http://thesocialnetwork.gccomponents.in/verification.php?username=$dusername&rand=$rand";*/
												
												if($result2 && $result3 && $result4 && $result5 && $result6 && $result7){
													echo '<span class="notice">Congratulations! Registration successful. <span class="shortlink"><a href="index.php">Login now</a></span></span>';
												}else{
													echo '<div class="notice">Sorry, some error occured while registering details. Try again or report to developer at sharstiagarwal2207@gmail.com.</div>';
												}
											}else{
												echo '<span class="notice">This email id is already associated with some other account.</span>';
											}
										}
									}else{
										echo '<span class="notice">Sorry! username not available.</span>';
									}
								}
							}
						}else{
							echo '<span class="notice">Please fill up all fields first.</span>';
						}
					}
				?>
				<form name="registerform" id="registerform" action="register.php" method="post" onsubmit="return validation();" >
					<p>First name: <input type="text" name="firstname" id="firstname" size="20" /></p>
					<p>Last name: <input type="text" name="lastname" id="lastname" size="20" /></p>
					<p>Email: <input type="text" name="email" id="email" size="20" /></p>
					<p>Desired username: <input type="text" name="dusername" id="dusername" size="20" /></p>
					<span id="availabilitystatus"></span>
					<p><input type="button" name="checkavailability" id="checkavailability" value="Check availability" /></p>
					<p>Password: <input type="password" name="password" id="password" size="20" /></p>
					<p>Confirm Password: <input type="password" name="cpassword" id="cpassword" size="20" /></p>
					<p><input type="submit" name="register" id="register" value="Register" size="20" /></p>
				</form>
			</div>
			<script type="text/javascript" src="js/jquery.js"></script>
			<script type="text/javascript">
				$(document).ready(function(){
					$('#checkavailability').click(function(){
						$('#availabilitystatus').html('<img src="images/checking.gif" />Checking . . .');
						dusername=$('#dusername').val();
						if(dusername==''){
							$('#availabilitystatus').html('<span class="notice">Please enter a username first.</span>');
						}else{
							if(window.XMLHttpRequest){
								xmlhttp=new XMLHttpRequest();
							}else{
								xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
							}
							xmlhttp.onreadystatechange=function(){
								if(xmlhttp.readyState==4 && xmlhttp.status==200){
									$('#availabilitystatus').html(xmlhttp.responseText);
								}
							}
							xmlhttp.open("GET","checkavailability.php?q="+dusername,true);
							xmlhttp.send();							
							}
					});
				});
			</script>
		</section>

<?php require('footer.php') ?>