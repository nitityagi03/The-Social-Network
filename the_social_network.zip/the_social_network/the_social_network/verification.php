<?php ob_start(); ?>
<?php require('header.php') ?>

		<section id="whiteSpace" style="height:500px;">
			
			<?php
				echo '<span class="notice">No need of email verification. Simply login to your account.</span>';
				/*
				if(isset($_GET['rand']) && isset($_GET['username'])){
					require('connection.php');
					$rand=mysql_real_escape_string(htmlentities($_GET['rand']));
					$username=mysql_real_escape_string(htmlentities($_GET['username']));
					$querycheckrand="select * from verificationtable where username='$username' and rand='$rand'";
					$resultcheckrand=mysql_query($querycheckrand);
					if($resultcheckrand){
						if(mysql_num_rows($resultcheckrand)==1){
							$arraydetails=mysql_fetch_assoc($resultcheckrand);
							$firstname=$arraydetails['firstname'];
							$lastname=$arraydetails['lastname'];
							$email=$arraydetails['email'];
							$dusername=$arraydetails['username'];
							$password=$arraydetails['password'];
							$rand=$arraydetails['rand'];
							$queryinsertintomaintable="insert into usernamepassword (firstname,lastname,email,username,password)values('$firstname','$lastname','$email','$dusername','$password')";
							$resultinsertintomaintable=mysql_query($queryinsertintomaintable);
							
							$query3="create table ".$dusername."comments (id smallint primary key auto_increment,postid smallint,postby varchar(100),commentby varchar(100),comment text,datetime datetime)";
							$result3=mysql_query($query3);
							$query4="create table ".$dusername."posts (id smallint primary key auto_increment,post text,postby varchar(100),datetime datetime)";
							$result4=mysql_query($query4);
							$query5="create table ".$dusername."friends (id smallint primary key auto_increment,friendusername varchar(255),friendfname varchar(255),friendlname varchar(255),friendemail varchar(255))";
							$result5=mysql_query($query5);
							$query6="create table ".$dusername."friendrequests (id smallint primary key auto_increment,friendrequestfirstname varchar(100),friendrequestlastname varchar(100),friendrequestusername varchar(100),friendrequestemail varchar(100))";
							$result6=mysql_query($query6);
							$query7="create table ".$dusername."photos (id smallint primary key auto_increment,name varchar(255),path varchar(255))";
							$result7=mysql_query($query7);
							
							$query8="delete from verificationtable where username='$dusername' and rand='$rand'";
							$result8=mysql_query($query8);
							if($resultinsertintomaintable && $result3 && $result4 && $result5 && $result6 && $result7 && $result8){
								echo '<span class="notice">Congratulations! Registration successful. <span class="shortlink"><a href="index.php">Login now</a></span></span>';
							}
						}else{
							echo '<span class="notice">You are either already registered or not entered the correct URL.</span>';
						}
					}
				}
			*/
			?>
			
			
		</section>

<?php require('footer.php') ?>