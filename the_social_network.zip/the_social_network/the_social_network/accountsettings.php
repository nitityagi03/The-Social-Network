<?php ob_start(); ?>
<?php require('header.php') ?>
		<section id="whiteSpace" style="height:500px;">
		
		<?php
			session_start();
			if(isset($_SESSION['username'])){
			echo '<div style="background-color:#f1f1f1;margin:10px 0px;padding:5px;">Hi '.$_SESSION['username'].'.<span style="margin-left:600px;" ></span>
					<div class="shortlink" style="float:right;"><a href="logout.php">Logout</a></div></div>';
			echo '<table cellpadding="5px" cellspacing="5px" border="0" id="accountlinks">
						<tr>
							<td><a href="account.php" >Home</a></td>
						</tr>
						<tr>
							<td><a href="friends.php" >Friends</a></td>
						</tr>
						<tr>
							<td><a href="#" >Posts</a></td>
						</tr>
						<tr>
							<td><a href="#" >Notifications</a></td>
						</tr>		
						<tr>
							<td><a href="accountsettings.php" >Account Settings</a></td>
						</tr>
					</table>';
				require('connection.php');
				if(isset($_POST['savebutton'])){
					$firstnameentered=mysql_real_escape_string(htmlentities($_POST['firstname']));
					$lastnameentered=mysql_real_escape_string(htmlentities($_POST['lastname']));
					$passwordentered=mysql_real_escape_string(htmlentities($_POST['password']));
					if(!empty($firstnameentered) && !empty($lastnameentered) && !empty($passwordentered)){
						$queryupdate="update usernamepassword set firstname='$firstnameentered',lastname='$lastnameentered',password='$passwordentered' where username='".$_SESSION['username']."'";
						$resultupdate=mysql_query($queryupdate);
						if($resultupdate){
							echo '<span class="notice">Details updated. Review your current details below.</span>';
						}else{
							echo '<div class="notice">Some error occured while updating. Plese try again or report to developer at sharstiagarwal2207@gmail.com.</div>';
						}
					}else{
						echo '<span class="notice">You left some field blank. Please enter all fields.</span>';
					}
				}
				$queryretrieveuserdetails="select * from usernamepassword where username='".$_SESSION['username']."'";s
				$resultretrieveuserdetails=mysql_query($queryretrieveuserdetails);
				if($resultretrieveuserdetails){
					if(mysql_num_rows($resultretrieveuserdetails)==1){
						$arrayuserdetails=mysql_fetch_assoc($resultretrieveuserdetails);
						$firstname=$arrayuserdetails['firstname'];
						$lastname=$arrayuserdetails['lastname'];
						$password=$arrayuserdetails['password'];
						echo "<form method='post' action='accountsettings.php'>
							<p>First Name: <input type='text' name='firstname' value='$firstname' /></p>
							<p>Last Name: <input type='text' name='lastname' value='$lastname' /></p>
							<p>Password: <input type='text' name='password' value='$password' autocomplete='off' /></p>
							<p><input type='submit' value='Save' name='savebutton' /></p>
						</form>";
					}
				}
			}else{
				echo '<span class="notice">Please login first. <span class="shortlink"><a href="index.php">Login</a></span></span>';
			}
		?>
		
		</section>

<?php require('footer.php') ?>