<?php ob_start(); ?>
<?php require('header.php') ?>

		<section id="whiteSpace" style="height:1000px;overflow:auto;">
			<?php
				session_start();
				if(isset($_SESSION['username'])){
					echo '<div style="background-color:#f1f1f1;margin:10px 0px;padding:5px;">Hi '.$_SESSION['username'].'.<span style="margin-left:600px;" ></span>
					<div class="shortlink" style="float:right;"><a href="logout.php">Logout</a></div></div>';
					
					?>
					<table cellpadding="5px" cellspacing="5px" border="0" id="accountlinks">
						<tr>
							<td><a href="account.php" >Home</a></td>
						</tr>
						<tr>
							<td><a href="friends.php" >Friends</a></td>
						</tr>
						<tr>
							<td><a href="#" >Posts</a></td>
						</tr>
						<tr>
							<td><a href="#" >Notifications</a></td>
						</tr>		
						<tr>
							<td><a href="accountsettings.php" >Account Settings</a></td>
						</tr>
					</table>
					<div id="searchfriendsdiv">
						<form action="friends.php" method="post">
							Search friends: <input type="text" size="30" id="friendsearchinput" name="friendsearchinput" placeholder="Enter email id" />
							<input type="submit" value="Find" id="searchfriendsbutton" name="searchfriendsbutton" />
						</form>
						<?php
							$currentuserusername=$_SESSION['username'];
							require('connection.php');
							$queryretrievecurrentuserdetails="select * from usernamepassword where username='$currentuserusername'";
							$resultretrievecurrentuserdetails=mysql_query($queryretrievecurrentuserdetails);
							if($resultretrievecurrentuserdetails){
								if(mysql_num_rows($resultretrievecurrentuserdetails)==1){
									$arraycurrentuser=mysql_fetch_assoc($resultretrievecurrentuserdetails);
									$currentuserfirstname=$arraycurrentuser['firstname'];
									$currentuserlastname=$arraycurrentuser['lastname'];
									$currentuseremail=$arraycurrentuser['email'];
								}
							}
							if(isset($_POST['searchfriendsbutton'])){
								require('connection.php');
								$friendemail=$_POST['friendsearchinput'];
								$friendemail=mysql_real_escape_string(htmlentities($friendemail));
								if(!empty($friendemail)){
									if($friendemail!=$currentuseremail){
										$queryfriendsearch="select * from usernamepassword where email='$friendemail'";
										$resultfriendsearch=mysql_query($queryfriendsearch);
										if($resultfriendsearch){
											if(mysql_num_rows($resultfriendsearch)==1){
												$arrayfriendsfound=mysql_fetch_assoc($resultfriendsearch);
												echo '<span class="notice">Friend Found !</span>
												<div class="singlefrienddiv">Name: '.$arrayfriendsfound['firstname'].' '.$arrayfriendsfound['lastname'].'<br/>
												Username: '.$arrayfriendsfound['username'].'<br/>Email: '.$arrayfriendsfound['email'].'</div>
												<form action="friends.php" method="post" name="sendrequestform" id="sendrequestform">';
												$querycheckfriendexist="select * from ".$_SESSION['username']."friends where friendusername='".$arrayfriendsfound['username']."'";
												$resultcheckfriendexist=mysql_query($querycheckfriendexist);
												
												$querycheckifalreadysentmerequest="select * from ".$_SESSION['username']."friendrequests where friendrequestemail='$friendemail'";
												$resultcheckifalreadysentmerequest=mysql_query($querycheckifalreadysentmerequest);
												if($resultcheckifalreadysentmerequest){
													if(mysql_num_rows($resultcheckifalreadysentmerequest)>0){
														$alreadysentmerequest='true';
													}else{
														$alreadysentmerequest='false';
													}
												}
												
												$querycheckifalreadysentrequest="select * from ".$arrayfriendsfound['username']."friendrequests where friendrequestusername='".$_SESSION['username']."'";
												$resultcheckifalreadysentrequest=mysql_query($querycheckifalreadysentrequest);
												if($resultcheckifalreadysentrequest){
													if(mysql_num_rows($resultcheckifalreadysentrequest)>0){
														$alreadysentrequest='true';
													}else{
														$alreadysentrequest='false';
													}
												}
												
												if($resultcheckfriendexist){
													if(mysql_num_rows($resultcheckfriendexist)==1){
														echo '<input type="button" value="This user is already your friend." disabled="disabled" />';
													}else if($alreadysentmerequest=='true'){
														echo '<input type="button" value="User has already sent you friend request." disabled="disabled" />';
													}else if($alreadysentrequest=='true'){
														echo '<input type="button" value="Friend request already sent." disabled="disabled" />';
													}else if(mysql_num_rows($resultcheckfriendexist)==0){
														echo '<input type="submit" value="Send Friend Request!" name="sendrequestbutton" name="sendrequestbutton" />';
														echo '<input type="hidden" name="hiddenusername" id="hiddenusername" value="'.$arrayfriendsfound['username'].'" />';
													}
												}
												echo '</form>';
											}else{
												echo '<span class="notice">No friend found associated with this email id.</span>';
											}
										}else{
											echo '<span class="notice">Some error occured while getting email id.</span>';
										}
									}else{
										echo '<span class="notice">This is your email. Please enter someone other\'s.</span>';
									}
									
								}else{
									echo '<span class="notice">Please enter a email id first.</span>';
								}
							}
							if(isset($_POST['sendrequestbutton'])){
								$usernametosendrequest=$_POST['hiddenusername'];
								require('connection.php');
								$querysendrequest="insert into ".$usernametosendrequest."friendrequests (friendrequestfirstname,friendrequestlastname,friendrequestusername,friendrequestemail)values('$currentuserfirstname','$currentuserlastname','$currentuserusername','$currentuseremail')";
								$resultsendrequest=mysql_query($querysendrequest);
								if($resultsendrequest){
									echo '<span class="notice">Friend request sent!</span>';
									header("Refresh: 0; url=friends.php");
								}else{
									echo '<span class="notice">Some error occured while sending request.</span>';
								}
							}
						?>
					</div>
					<div id="friendsdiv" style="float:left;">
						<?php
							require('connection.php');
							$queryretrievefriends="select * from ".$_SESSION['username']."friends";
							$resultretrievefriends=mysql_query($queryretrievefriends);
							if($resultretrievefriends){
								if(mysql_num_rows($resultretrievefriends)!=0){
									while($arrayfriends=mysql_fetch_assoc($resultretrievefriends)){
										echo '<div class="singlefrienddiv">Name: '.$arrayfriends['friendfname'].' '.$arrayfriends['friendlname'].'<br/>
										Username: '.$arrayfriends['friendusername'].'<br/>Email: '.$arrayfriends['friendemail'].'</div>';
									}
								}else{
									echo '<span class="notice">No friends till date.</span>';
								}
							}else{
								echo '<span class="notice">Sorry some error occured while retrieving friends.</span>';
							}
						?>
					</div>
					<?php
				}else{
					echo '<span class="notice">Please login first.
					<span class="shortlink"><a href="index.php">Login</a></span></span>';
				}
			?>
			
		</section>

<?php require('footer.php') ?>