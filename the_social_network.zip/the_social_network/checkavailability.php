<?php
	if(isset($_GET['q'])){
		$q=$_GET['q'];
		require('connection.php');
		$query="select * from usernamepassword where username='$q'";
		$result=@mysql_query($query);
		if($result){
			if(@mysql_num_rows($result)==0){
				echo '<span class="notice">username available!</span>';
			}else{
				echo '<span class="notice">Sorry! username not available.</span>';
			}
		}
	}
?>